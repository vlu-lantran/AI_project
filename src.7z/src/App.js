import React, { useState } from 'react';
import './App.css';
import Dashboard from './components/Dashboard';
import VideoLibrary from './components/VideoLibrary';
import VideoPlayer from './components/VideoPlayer';

function App() {
  const [activeTab, setActiveTab] = useState("Dashboard");
  const [watchedVideos, setWatchedVideos] = useState([]);  // Trạng thái video đã xem
  const [currentVideo, setCurrentVideo] = useState(null);   // Trạng thái video hiện tại

  // Thêm các trạng thái cho tìm kiếm và lọc
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const addWatchedVideo = (video) => {
    setWatchedVideos((prevVideos) => {
      const updatedVideos = [...prevVideos, video];
      return updatedVideos;
    });
  };

  const selectVideo = (video) => {
    setCurrentVideo(video); // Cập nhật video hiện tại
    setActiveTab("VideoPlayer"); // Chuyển tab sang VideoPlayer
  };

  return (
    <div className="app">
      <header className="header">
        <div className="logo">
          {/* Hiển thị logo bằng hình ảnh */}
          <img 
            src="/Cam.png"  // Đảm bảo rằng logo được đặt trong thư mục public
            alt="AI Camera Logo"
            style={{ width: '150px', height: 'auto' }} // Điều chỉnh kích thước của logo
          />
        </div>
        <nav className="nav">
          <button
            className={activeTab === "Dashboard" ? "active" : ""}
            onClick={() => handleTabClick("Dashboard")}
          >
            Dashboard
          </button>
          <button
            className={activeTab === "VideoLibrary" ? "active" : ""}
            onClick={() => handleTabClick("VideoLibrary")}
          >
            Video Library
          </button>
        </nav>
      </header>

      <main className="main-content">
        {activeTab === "Dashboard" && <Dashboard watchedVideos={watchedVideos} />}
        
        {activeTab === "VideoLibrary" && (
          <VideoLibrary 
            selectVideo={selectVideo} 
            searchQuery={searchQuery} 
            setSearchQuery={setSearchQuery} 
            filterDate={filterDate} 
            setFilterDate={setFilterDate}
          />
        )}

        {/* Hiển thị VideoPlayer khi người dùng chọn một video */}
        {activeTab === "VideoPlayer" && currentVideo && (
          <VideoPlayer 
            video={currentVideo} 
            addWatchedVideo={addWatchedVideo} 
          />
        )}
      </main>
    </div>
  );
}

export default App;
