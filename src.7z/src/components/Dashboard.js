import React from 'react';

function Dashboard({ watchedVideos }) {
  return (
    <div className="dashboard">
      <h2>Video đã xem</h2>
      <div className="watched-videos">
        {watchedVideos.length > 0 ? (
          <ul>
            {watchedVideos.map((video, index) => (
              <li key={index}>
                {/* Hiển thị thumbnail của video */}
                <div className="video-thumbnail">
                  <video width="100%" height="auto" muted>
                    <source src={video.url} type="video/mp4" />
                    Your browser does not support the video tag.
                  </video>
                </div>
                {/* Hiển thị tên video và ngày xem */}
                <h3>{video.title}</h3>
                <p>Ngày xem: {video.date}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p>Chưa xem video nào.</p>
        )}
      </div>
    </div>
  );
}

export default Dashboard;
