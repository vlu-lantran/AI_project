import React, { useState } from 'react';

function VideoLibrary({ selectVideo }) {
  // Danh sách video ban đầu
  const videos = [
    { id: 1, title: 'VIDEO 1', date: '2024-11-09', tags: ['tutorial'], url: "./videos/video1.mp4" },
    { id: 2, title: 'VIDEO 1', date: '2024-11-09', tags: ['tutorial'], url: "./videos/video1.mp4" },
    { id: 3, title: 'VIDEO 1', date: '2024-11-09', tags: ['tutorial'], url: "./videos/video1.mp4" },
    { id: 4, title: 'VIDEO 1', date: '2024-11-09', tags: ['tutorial'], url: "./videos/video1.mp4" },
    // ... các video khác
  ];

  // Trạng thái tìm kiếm theo tên
  const [searchQuery, setSearchQuery] = useState('');

  // Trạng thái lọc theo ngày
  const [filterDate, setFilterDate] = useState('');

  // Trạng thái lọc theo thẻ
  const [filterTag, setFilterTag] = useState('');

  // Lọc video theo tên, ngày và thẻ
  const filteredVideos = videos.filter(video => {
    const matchesTitle = video.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDate = filterDate ? video.date === filterDate : true;
    const matchesTag = filterTag ? video.tags.some(tag => tag.toLowerCase().includes(filterTag.toLowerCase())) : true;
    return matchesTitle && matchesDate && matchesTag;
  });

  return (
    <div className="video-library">
      <h2>Video gần đây</h2>

      {/* Form Tìm kiếm và lọc */}
      <div className="filter-controls">
        <input
          type="text"
          placeholder="Search by name..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <input
          type="date"
          value={filterDate}
          onChange={(e) => setFilterDate(e.target.value)}
        />
        <input
          type="text"
      
          placeholder="Filter by tag..."
          value={filterTag}
          onChange={(e) => setFilterTag(e.target.value)}
        />
      </div>

      {/* Thông báo nếu không có video nào */}
      {filteredVideos.length === 0 && <p>There are no videos matching the search and filter criteria.</p>}

      {/* Hiển thị video đã lọc theo hàng ngang */}
      <div className="video-grid">
        {filteredVideos.map((video, index) => (
          <div
            key={video.id}
            className="video-card"
            onClick={() => selectVideo(video)}
          >
            <div className="video-thumbnail">
              <video width="200" height="100" muted>
                <source src={video.url} type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>
            <h3>{video.title}</h3>
            <p>Ngày: {video.date}</p>
            <p>Thẻ: {video.tags.join(', ')}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default VideoLibrary;