import React, { useEffect, useRef } from 'react';

function VideoPlayer({ video, addWatchedVideo, goBack }) {
  const videoRef = useRef(null);

  useEffect(() => {
    if (video && videoRef.current) {
      videoRef.current.play();
    }
  }, [video]);

  const handleVideoEnd = () => {
    if (video) {
      addWatchedVideo(video); // Gọi hàm addWatchedVideo khi video kết thúc
    }
  };

  return (
    <div className="video-player">
      {video ? (
        <>
          <video
            ref={videoRef}
            width="80%"
            height="auto"
            controls
            onEnded={handleVideoEnd}
          >
            <source src={video.url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="video-info">
            <h2>{video.title}</h2>
            <p><strong>Ngày:</strong> {video.date}</p>
            {video.description && <p><strong>Mô tả:</strong> {video.description}</p>}
            <p><strong>Thời lượng:</strong> {video.duration ? video.duration : 'No information available'}</p>
          </div>
        </>
      ) : (
        <p>No Videos Selected.</p>
      )}
    </div>
  );
}

export default VideoPlayer;
